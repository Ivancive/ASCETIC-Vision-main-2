# =========================================
# SERVER PRINCIPALE — ASCETIC-Vision
# =========================================

# Utilità comuni lato server (funzioni helper, ecc.)
source("server/utils.R")

# Carica tutti i moduli server (definiti in server/modules/)
source("server/load_modules.R")

server <- function(input, output, session) {
    
    # ============================
    # HOME / PROJECT LIST
    # ============================

    # Reactive con l’elenco delle cartelle progetto
    project_dirs <- reactive({

      base_dir <- "output_project"

      if (!dir.exists(base_dir)) {
        return(data.frame(
          Project = character(0),
          stringsAsFactors = FALSE
        ))
      }

      dirs <- list.dirs(base_dir, full.names = TRUE, recursive = FALSE)

      if (length(dirs) == 0) {
        return(data.frame(
          Project = character(0),
          stringsAsFactors = FALSE
        ))
      }

      data.frame(
        Project = basename(dirs),
        stringsAsFactors = FALSE
      )
    })

    # Tabella in Home page
    output$projectList <- DT::renderDT({
      DT::datatable(
        project_dirs(),
        selection = "single",
        options = list(
          scrollX = TRUE,
          dom = "t",
          pageLength = 20
        )
      )
    })

    # Testo in alto a destra nell’header (uiOutput("project_info"))
    output$project_info <- renderUI({
      tags$span("No project loaded")
    })

    # Pulsante "Load existing project"
    observeEvent(input$loadProjBtn, {

      sel <- input$projectList_rows_selected

      if (is.null(sel) || length(sel) == 0) {
        showNotification("Select a project from the list first.", type = "warning")
        return(NULL)
      }

      proj_name <- project_dirs()$Project[sel]

      # Per ora solo messaggio; il caricamento completo lo implementiamo in un secondo step
      showNotification(
        paste("Project selected:", proj_name,
              "— loading from disk still to be implemented in modular version."),
        type = "message",
        duration = 5
      )
    })

    # Pulsante "Create New Project"
    observeEvent(input$create_project_button, {
      showNotification(
        "New analysis started. You can now go to 'Input data - Genomic' and upload your files.",
        type = "message",
        duration = 5
      )
    })


  # -----------------------------
  # REACTIVE VALUES (GLOBAL STATE)
  # -----------------------------
  reshaped_data        <- reactiveVal(NULL)
  reshaped_data2       <- reactiveVal(NULL)
  reshaped_data_matrix <- reactiveVal(NULL)

  genotype_table       <- reactiveVal(NULL)
  genotype_table_surv  <- reactiveVal(NULL)

  resampling_res       <- reactiveVal(NULL)
  conf_res             <- reactiveVal(NULL)

  surv_data            <- reactiveVal(NULL)
  reshaped_dataSurv    <- reactiveVal(NULL)
  orig_genotypeSurv    <- reactiveVal(NULL)
  orig_dataSurv        <- reactiveVal(NULL)
  evo_step             <- reactiveVal(NULL)

  resExampleEvosigs    <- reactiveVal(NULL)

  # tipo di dato per inferenza / survival
  case                 <- reactiveVal(NULL)
  case_surv            <- reactiveVal(NULL)

  selected_folder      <- reactiveVal(NULL)

  visualizeInferenceOutput  <- reactiveVal(FALSE)
  visualizeConfidenceOutput <- reactiveVal(FALSE)
  visualize_output_surv     <- reactiveVal(FALSE)

  # --------------------------------------------
  # ATTACH MODULES E PASSAGGIO DELLE REATTIVE
  # --------------------------------------------

  # 1. Input Genotype + gestione tabella reshaped
  module_input_data_server(
    input  = input,
    output = output,
    session = session,
    reshaped_data        = reshaped_data,
    reshaped_data_matrix = reshaped_data_matrix,
    reshaped_data2       = reshaped_data2,
    genotype_table       = genotype_table,
    case                 = case,
    selected_folder      = selected_folder
  )

  # 2. Resampling (bulk single)
  module_resampling_server(
    input  = input,
    output = output,
    session = session,
    reshaped_data2 = reshaped_data2
  )

  # 3. Inference
  module_inference_server(
    input  = input,
    output = output,
    session = session,
    reshaped_data        = reshaped_data,
    reshaped_data_matrix = reshaped_data_matrix,
    genotype_table       = genotype_table,
    reshaped_data2       = reshaped_data2,
    case                 = case,
    selected_folder      = selected_folder,
    resampling_res       = resampling_res,
    visualizeInferenceOutput = visualizeInferenceOutput
  )

  # 4. Confidence estimation
  module_confidence_server(
    input  = input,
    output = output,
    session = session,
    reshaped_data2       = reshaped_data2,
    resampling_res       = resampling_res,
    conf_res             = conf_res,
    case                 = case,
    visualizeConfidenceOutput = visualizeConfidenceOutput
  )

  # 5. Survival — input genotype / survival file
  module_survival_input_server(
    input  = input,
    output = output,
    session = session,
    reshaped_dataSurv   = reshaped_dataSurv,
    orig_genotypeSurv   = orig_genotypeSurv,
    genotype_table_surv = genotype_table_surv,
    case_surv           = case_surv
  )

  # 6. Survival — calcolo evolutionary steps
  module_survival_steps_server(
    input  = input,
    output = output,
    session = session,
    case                 = case,
    case_surv           = case_surv,
    reshaped_data_matrix = reshaped_data_matrix,
    reshaped_dataSurv    = reshaped_dataSurv,
    orig_genotypeSurv    = orig_genotypeSurv,
    evo_step             = evo_step,
    surv_data            = surv_data,
    genotype_table       = genotype_table,
    genotype_table_surv  = genotype_table_surv
  )

  # 7. Survival — evoSigs e grafici
  module_survival_output_server(
    input  = input,
    output = output,
    session = session,
    surv_data          = surv_data,
    evo_step           = evo_step,
    resExampleEvosigs  = resExampleEvosigs,
    visualize_output_surv = visualize_output_surv
  )

  # 8. Save project
  module_save_project_server(
    input  = input,
    output = output,
    session = session,
    case               = case,
    case_surv          = case_surv,
    reshaped_data      = reshaped_data,
    reshaped_data2     = reshaped_data2,
    reshaped_dataSurv  = reshaped_dataSurv,
    orig_genotypeSurv  = orig_genotypeSurv,
    reshaped_data_matrix = reshaped_data_matrix,
    surv_data          = surv_data,
    resampling_res     = resampling_res,
    conf_res           = conf_res,
    evo_step           = evo_step,
    resExampleEvosigs  = resExampleEvosigs,
    selected_folder    = selected_folder
  )

}

