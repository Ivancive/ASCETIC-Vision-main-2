module_inference_server <- function(input, output, session,
                                    reshaped_data,
                                    reshaped_data_matrix,
                                    genotype_table,
                                    reshaped_data2,
                                    case,
                                    selected_folder,
                                    resampling_res,
                                    visualizeInferenceOutput) {


  # ============================================================
  # BINARIZATION (corregge 100% logica del tuo codice originale)
  # ============================================================
  binarize_table <- function(filter, filter_perc, mat, case_type) {

    mat <- as.matrix(mat)

    if (is.na(filter)) {
      showNotification("Enter a valid binarization threshold", type = "error")
      return(NULL)
    }

    # -----------------------------
    # BULK SINGLE or SINGLE CELL
    # -----------------------------
    if (case_type %in% c("bulk_single", "single_cell")) {

      bin <- ifelse(mat >= filter, 1, 0)
      genotype_table(bin)
      return(bin)
    }

    # -----------------------------
    # BULK MULTIPLE (con prevalence)
    # -----------------------------
    if (case_type == "bulk_multiple") {

      bin <- ifelse(mat >= filter, 1, 0)

      df <- as.data.frame(bin)
      df$id <- sub("\\t.*$", "", rownames(df))

      result <- df %>%
        group_by(id) %>%
        summarize(across(everything(), ~ mean(. != 0))) %>%
        as.data.frame()

      rownames(result) <- result$id
      result$id <- NULL

      if (is.na(filter_perc)) {
        showNotification("Enter a prevalence threshold", type = "error")
        return(NULL)
      }

      bin2 <- ifelse(as.matrix(result) >= filter_perc, 1, 0)

      genotype_table(bin2)
      return(bin2)
    }

    showNotification("Unknown case type", type = "error")
    return(NULL)
  }



  # ============================================================
  # MAIN INFERENCE BUTTON
  # ============================================================
  observeEvent(input$submitBtn, {

    # --------------------------
    # CHECKS PRELIMINARI
    # --------------------------
    if (is.null(case())) {
      showNotification("Upload genomic file first", type = "error")
      return()
    }

    if (is.null(reshaped_data_matrix())) {
      showNotification("Internal error: genotype matrix is empty", type = "error")
      return()
    }

    if (input$resamplingFlag == FALSE &&
        (is.null(input$regularization) || is.null(input$command) ||
         is.na(input$restarts) || is.na(input$seed))) {

      showNotification("Fill all inference fields", type = "error")
      return()
    }

    if (input$resamplingFlag == TRUE &&
        (is.null(input$regularization) || is.null(input$command) ||
         is.na(input$restarts) || is.na(input$seed) || is.na(input$nresampling))) {

      showNotification("Fill all resampling fields", type = "error")
      return()
    }


    # --------------------------
    # OPEN WAIT MODAL
    # --------------------------
    showModal(modalDialog(
      title = "Processing",
      div(style = "text-align:center;",
          tags$i(class = "fa fa-hourglass-half fa-spin"),
          p("Inference in progress...")
      ),
      easyClose = FALSE,
      footer = NULL
    ))


    # --------------------------
    # APPLY BINARIZATION TO INPUT
    # --------------------------
    filter      <- input$binarization
    filter_perc <- input$binarization_perc

    bin <- binarize_table(filter, filter_perc, reshaped_data_matrix(), case())

    if (is.null(bin)) {
      removeModal()
      return()
    }


    # --------------------------
    # INFERENCE EXECUTION
    # --------------------------
    out <- NULL

    tryCatch({

      set.seed(input$seed)

      # ====================================================
      # CASE 1 — BULK SINGLE
      # ====================================================
      if (case() == "bulk_single") {

        column <- intersect(colnames(bin), colnames(reshaped_data()))
        row    <- intersect(rownames(bin), rownames(reshaped_data()))

        ccfTable <- reshaped_data()[row, column, drop = FALSE]

        if (!input$resamplingFlag) {

          out <- asceticCCF(
            dataset      = bin,
            ccfDataset   = ccfTable,
            regularization = input$regularization,
            command      = input$command,
            restarts     = input$restarts
          )

        } else {

          out <- asceticCCFResampling(
            dataset      = bin,
            ccfDataset   = ccfTable,
            vafDataset   = reshaped_data2(),
            nsampling    = input$nresampling,
            regularization = input$regularization,
            command      = input$command,
            restarts     = input$restarts
          )
        }
      }


      # ====================================================
      # CASE 2 — BULK MULTIPLE or SINGLE CELL
      # ====================================================
      if (case() %in% c("bulk_multiple", "single_cell")) {

        # Folder required
        if (is.null(selected_folder())) {
          showNotification("Select folder containing model matrices", type = "error")
          removeModal()
          return()
        }

        models <- readMatrixFiles(selected_folder())

        # Apply delete-column to models (your original logic)
        if (!is.null(input$DeleteColumn) && length(input$DeleteColumn) > 0) {
          for (m in names(models)) {

            M <- as.matrix(models[[m]])

            for (col in input$DeleteColumn) {
              if (col %in% colnames(M)) {
                idx <- which(colnames(M) == col)

                # node adjustments (same as your original logic)
                if (any(M[, idx] == 1) && all(M[idx, -idx] == 0)) {
                  M[M[, idx] == 1, idx] <- 0
                }

                if (any(M[idx, -idx] == 1) && all(M[, idx] == 0)) {
                  M[idx, -idx][M[idx, -idx] == 1] <- 0
                }

                if (any(M[, idx] == 1) && any(M[idx, -idx] == 1)) {
                  rows <- which(M[, idx] == 1)
                  for (r in rows) {
                    M[r, -idx] <- M[r, -idx] | M[idx, -idx]
                  }
                  M[rows, idx] <- 0
                  M[idx, -idx] <- 0
                }

                # remove column and row
                M <- M[-idx, -idx]
              }
            }

            models[[m]] <- M
          }
        }


        if (!input$resamplingFlag) {

          out <- asceticPhylogenies(
            dataset        = bin,
            models         = models,
            regularization = input$regularization,
            command        = input$command,
            restarts       = input$restarts
          )

        } else {

          out <- asceticPhylogeniesBootstrap(
            dataset        = bin,
            models         = models,
            nsampling      = input$nresampling,
            regularization = input$regularization,
            command        = input$command,
            restarts       = input$restarts
          )
        }
      }

      # SAVE RESULT
      resampling_res(out)

      removeModal()

      # SHOW OUTPUT CONTROLS
      visualizeInferenceOutput(TRUE)

      # Set dynamic selector for output
      output$visualize_inference <- renderUI({

        names_to_remove <- c("dataset", "models", "ccfDataset", "inference")
        names <- setdiff(names(out), names_to_remove)
        names <- c(names, names(out$inference))

        selectInput("visualize_inference",
                    "Select output",
                    choices = names,
                    selected = ifelse("rankingEstimate" %in% names, "rankingEstimate", names[1]))
      })

    },
    error = function(e) {

      removeModal()
      visualizeInferenceOutput(FALSE)
      output$visualize_inference <- NULL
      output$selected_result_output <- NULL
      output$graph_inference <- NULL

      showNotification("Inference failed: check data and model folder", type = "error")
      message("ERROR:", e$message)
    })

  })


  # ============================================================
  # DISPLAY OUTPUT (ranking, poset, DAG)
  # ============================================================
  observe({

    req(input$sidebarMenu == "inference")
    req(input$visualize_inference)
    req(resampling_res())
    req(visualizeInferenceOutput())

    out <- resampling_res()

    # Which output is selected?
    sel <- input$visualize_inference

    # rankingEstimate
    if (sel == "rankingEstimate") {

      df <- out$rankingEstimate
      df$genes <- rownames(df)
      df$rank <- as.integer(df$rank) + 1
      df <- df[, c("genes", "rank")]

      output$graph_inference <- NULL

      output$selected_result_output <- renderDT({
        datatable(df,
                  options = list(scrollX = TRUE,
                                 order = list(list(1, "asc"))),
                  rownames = FALSE)
      })

      return()
    }


    # poset
    if (sel == "poset") {

      pos <- out$poset
      colnames(pos) <- colnames(out$dataset)
      rownames(pos) <- colnames(out$dataset)

      output$graph_inference <- NULL

      output$selected_result_output <- renderDT({
        datatable(pos,
                  options = list(scrollX = TRUE),
                  selection = "single")
      })

      return()
    }


    # DAG
    dag <- out$inference[[sel]]
    colnames(dag) <- colnames(out$dataset)
    rownames(dag) <- colnames(out$dataset)

    if (all(dag == 0)) {
      showNotification("No DAG available", type = "message")
      output$graph_inference <- NULL
      return()
    }

    g <- igraph::graph_from_adjacency_matrix(dag)

    # remove isolated nodes
    g <- igraph::delete_vertices(g, V(g)[degree(g) == 0])

    nodes <- data.frame(id = V(g)$name, label = V(g)$name)
    edges <- as.data.frame(igraph::as_edgelist(g))
    colnames(edges) <- c("from", "to")

    output$selected_result_output <- NULL

    output$graph_inference <- renderVisNetwork({
      generateVisNetwork(nodes, edges, mode = "inference")
    })
  })

}

