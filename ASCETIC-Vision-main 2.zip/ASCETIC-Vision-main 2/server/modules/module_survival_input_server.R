module_survival_input_server <- function(input, output, session,
                                         reshaped_dataSurv,
                                         orig_genotypeSurv,
                                         evo_step,
                                         surv_data,
                                         case_surv,
                                         visualize_del) {


  # =====================================================================
  # LOAD SURVIVAL FILE (SAMPLE, STATUS, TIMES)
  # =====================================================================
  observeEvent(input$loadBtn2_surv, {
    inFile <- input$dataFile2_surv

    if (is.null(inFile)) {
      showNotification("Please select a survival file.", type = "error")
      return()
    }

    df <- tryCatch({
      read.table(inFile$datapath, sep = "\t", header = TRUE, stringsAsFactors = FALSE)
    }, error = function(e) { NULL })

    if (is.null(df)) {
      showNotification("Could not read the selected file.", type = "error")
      return()
    }

    # Validate columns
    if (!all(c("SAMPLE", "STATUS", "TIMES") %in% colnames(df))) {
      showNotification("Survival file must contain: SAMPLE, STATUS, TIMES.", type = "error")
      return()
    }

    surv_data(df)
    showNotification("Survival file loaded successfully.", type = "message")
  })



  # =====================================================================
  # DYNAMIC: SHOW GENOTYPE TYPE SELECTION IF USER WANTS TO LOAD GENOTYPE
  # =====================================================================
  observeEvent(input$load_file, {
    if (input$load_file) {
      output$data_type_surv <- renderUI({
        selectInput("data_type_surv", "Select data type for genotype",
                    choices = c("Bulk single", "Bulk multiple", "Single cell"))
      })
    } else {
      output$data_type_surv <- renderUI(NULL)
    }
  })



  # =====================================================================
  # LOAD GENOTYPE FILE FOR SURVIVAL
  # =====================================================================
  observeEvent(input$loadBtn_surv, {

    inFile <- input$dataFile_surv
    output$dataTable_GenotypeSurv <- NULL
    output$heatmap_GenotypeSurv <- NULL

    if (is.null(inFile)) {
      showNotification("Please select a genotype file.", type = "error")
      return()
    }

    df <- tryCatch({
      read.table(inFile$datapath, sep = "\t", header = TRUE, stringsAsFactors = FALSE)
    }, error = function(e) { NULL })

    if (is.null(df)) {
      showNotification("Could not read the genotype file.", type = "error")
      return()
    }


    # --------------------------------------------------------------
    # CASE 1 — BULK SINGLE BIOPSY: SAMPLE GENE CCF
    # --------------------------------------------------------------
    if (ncol(df) == 3 &&
        all(colnames(df) == c("SAMPLE", "GENE", "CCF"))) {

      if (input$data_type_surv != "Bulk single") {
        showNotification("Selected type does not match file format.", type = "error")
        return()
      }

      case_surv("bulk_single")

      df <- distinct(df, SAMPLE, GENE, .keep_all = TRUE)

      M <- reshape2::acast(df, SAMPLE ~ GENE, value.var = "CCF", fill = 0)
      reshaped_dataSurv(M)

      orig_genotypeSurv(M)

      output$dataTable_GenotypeSurv <- renderDT({
        datatable(M, options = list(scrollX = TRUE))
      })

      output$heatmap_GenotypeSurv <- renderUI({
        generate_heatmap_plot(M)
      })

      output$binarization_surv <- renderUI({
        numericInput("binarization_surv",
                     "CCF threshold", value = 0.05, min = 0, max = 1, step = 0.01)
      })

      output$binarization_percSurv <- NULL
      visualize_del()
      return()
    }


    # --------------------------------------------------------------
    # CASE 2 — BULK MULTIPLE BIOPSY: SAMPLE REGION GENE CCF
    # --------------------------------------------------------------
    if (ncol(df) == 4 &&
        all(colnames(df) == c("SAMPLE", "REGION", "GENE", "CCF"))) {

      if (input$data_type_surv != "Bulk multiple") {
        showNotification("Selected type does not match file format.", type = "error")
        return()
      }

      case_surv("bulk_multiple")

      df <- distinct(df, SAMPLE, REGION, GENE, .keep_all = TRUE)

      M <- df %>%
        group_by(SAMPLE, REGION, GENE) %>%
        summarise(CCF = sum(CCF), .groups = "drop") %>%
        unite("ID", c("SAMPLE", "REGION"), sep = "\t") %>%
        tidyr::pivot_wider(names_from = GENE, values_from = CCF, values_fill = 0)

      M <- as.data.frame(M)
      rownames(M) <- M$ID
      M$ID <- NULL

      reshaped_dataSurv(M)
      orig_genotypeSurv(M)

      output$dataTable_GenotypeSurv <- renderDT({
        datatable(M, options = list(scrollX = TRUE))
      })

      output$heatmap_GenotypeSurv <- renderUI({
        generate_heatmap_plot(M)
      })

      output$binarization_surv <- renderUI({
        numericInput("binarization_surv", "CCF threshold", 0.05, 0, 1, 0.01)
      })

      output$binarization_percSurv <- renderUI({
        numericInput("binarization_percSurv", "Prevalence threshold", 0, 0, 1, 0.01)
      })

      visualize_del()
      return()
    }


    # --------------------------------------------------------------
    # CASE 3 — SINGLE CELL: PATIENT CELL GENE VALUE
    # --------------------------------------------------------------
    if (ncol(df) == 4 &&
        all(colnames(df) == c("PATIENT", "CELL", "GENE", "VALUE"))) {

      if (input$data_type_surv != "Single cell") {
        showNotification("Selected type does not match file format.", type = "error")
        return()
      }

      case_surv("single_cell")

      df <- distinct(df, PATIENT, CELL, GENE, .keep_all = TRUE)

      M <- df %>%
        group_by(PATIENT, GENE) %>%
        summarise(PERCENTAGE = mean(VALUE), .groups = "drop") %>%
        tidyr::pivot_wider(names_from = GENE, values_from = PERCENTAGE, values_fill = 0)

      M <- as.data.frame(M)
      rownames(M) <- M$PATIENT
      M$PATIENT <- NULL

      reshaped_dataSurv(M)
      orig_genotypeSurv(M)

      output$dataTable_GenotypeSurv <- renderDT({
        datatable(M, options = list(scrollX = TRUE))
      })

      output$heatmap_GenotypeSurv <- renderUI({
        generate_heatmap_plot(M)
      })

      output$binarization_surv <- renderUI({
        numericInput("binarization_surv", "CCF threshold", 0.05, 0, 1, 0.01)
      })

      output$binarization_percSurv <- NULL
      visualize_del()
      return()
    }


    # --------------------------------------------------------------
    # FALLBACK IN CASE OF UNKNOWN FORMAT
    # --------------------------------------------------------------
    showNotification("Genotype file format not recognized.", type = "error")
    return()
  })



  # =====================================================================
  # MANAGE EDITING OF GENOTYPE (DELETE ROW/COLUMN)
  # =====================================================================
  observe({
    req(orig_genotypeSurv())
    updated <- modify_reshaped_dataSurv(orig_genotypeSurv(),
                                        input$DeleteColumn_surv,
                                        input$DeleteRow_surv)

    reshaped_dataSurv(updated)

    output$dataTable_GenotypeSurv <- renderDT({
      datatable(updated, options = list(scrollX = TRUE))
    })
  })

}

