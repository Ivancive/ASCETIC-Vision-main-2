
module_survival_output_server <- function(input, output, session,
                                          evo_step,
                                          reshaped_dataSurv,
                                          surv_data,
                                          resExampleEvosigs,
                                          visualize_output_surv) {


  # =====================================================================
  # 1) CALCOLO EVOLUTIONARY STEPS PER SOPRAVVIVENZA
  # =====================================================================
  observeEvent(input$submit_surv, {

    if (is.null(reshaped_dataSurv())) {
      showNotification("Load a genotype file first.", type = "error")
      return()
    }

    if (is.null(surv_data())) {
      showNotification("Load a survival file first.", type = "error")
      return()
    }

    if (is.null(evo_step())) {
      showNotification("Compute evolutionary steps first.", type = "error")
      return()
    }

    showNotification("Evolutionary steps generated successfully.", type = "message")
  })



  # =====================================================================
  # 2) CALCOLO OUTPUT SOPRAVVIVENZA (evoSigs)
  # =====================================================================
  observeEvent(input$calc_surv, {

    if (is.null(evo_step())) {
      showNotification("Calculate evolutionary steps first.", type = "error")
      return()
    }

    if (is.null(surv_data())) {
      showNotification("Upload survival file first.", type = "error")
      return()
    }


    # ---- FILTER evolutionary steps based on prevalence threshold ----
    full <- evo_step()

    if (!is.na(input$binarization_surv2) && input$binarization_surv2 > 0) {

      threshold <- input$binarization_surv2

      cols_to_keep <- sapply(full, function(col) mean(col == 1) >= threshold)

      filtered <- full[, cols_to_keep, drop = FALSE]

      if (ncol(filtered) < 1) {
        showNotification("No evolutionary step passes the prevalence threshold.", type = "warning")
        return()
      }

    } else {
      filtered <- full
    }

    # ---- Check that some columns are not all-zero or all-one ----
    invalid_cols <- sapply(filtered, function(col) all(col == 0) || all(col == 1))

    if (any(invalid_cols)) {
      filtered <- filtered[, !invalid_cols, drop = FALSE]
      if (ncol(filtered) < 1) {
        showNotification("All evolutionary steps are constant (0 or 1). Cannot compute survival.", type = "error")
        return()
      }
    }


    # =====================================================================
    # RUN evoSigs()
    # =====================================================================
    showModal(modalDialog(
      title = "Processing",
      div(style = "text-align:center;",
          tags$i(class = "fa fa-hourglass-half fa-spin fa-2x"),
          p("Computing survival signatures...")
      ),
      footer = NULL,
      easyClose = FALSE
    ))

    result <- tryCatch({
      evoSigs(
        survivalData = surv_data(),
        evolutionarySteps = filtered
      )
    }, error = function(e) {
      removeModal()
      showNotification(paste("Error in evoSigs:", e$message), type = "error")
      return(NULL)
    })

    removeModal()

    if (is.null(result)) return()

    # Save evolutionary signatures
    resExampleEvosigs(result)

    visualize_output_surv(TRUE)

    showNotification("Survival analysis completed.", type = "message")
  })



  # =====================================================================
  # 3) RENDER OUTPUT SOPRAVVIVENZA
  # =====================================================================
  observe({
    req(visualize_output_surv())
    req(resExampleEvosigs())

    res <- resExampleEvosigs()

    # ---- Display hazard ratios, p-values, etc. ----
    output$surv_table <- renderDT({
      if (!is.null(res$summaryTable)) {
        datatable(res$summaryTable,
                  options = list(scrollX = TRUE),
                  rownames = FALSE)
      }
    })

    # ---- Display KM plots if present ----
    output$km_plot <- renderPlot({
      if (!is.null(res$KM_plot)) {
        print(res$KM_plot)
      }
    })

  })


}
