module_input_data_server <- function(input, output, session,
                                     reshaped_data,
                                     reshaped_data_matrix,
                                     reshaped_data2,
                                     genotype_table,
                                     case,
                                     selected_folder) {

  # ------------------------------------------------------------
  # FUNZIONE: applica delete-row / delete-column e aggiorna matrix
  # ------------------------------------------------------------
  apply_modifications <- function(df, del_cols, del_rows) {

    if (!is.null(del_cols) && length(del_cols) > 0) {
      df <- df[, !(colnames(df) %in% del_cols), drop = FALSE]
    }

    if (!is.null(del_rows) && length(del_rows) > 0) {
      df <- df[!(rownames(df) %in% del_rows), , drop = FALSE]
    }

    df
  }


  # ------------------------------------------------------------
  # CARICAMENTO GENOTYPE
  # ------------------------------------------------------------
  observeEvent(input$loadBtn, {
    inFile <- input$dataFile

    if (is.null(inFile)) {
      showNotification("Please select a file", type = "error")
      return()
    }

    data <- tryCatch(
      read.table(inFile$datapath, sep = "\t", header = TRUE, stringsAsFactors = FALSE),
      error = function(e) { NULL }
    )

    if (is.null(data)) {
      showNotification("Error reading the file.", type = "error")
      return()
    }

    # -------------------------------------
    # CASE 1 — BULK SINGLE
    # -------------------------------------
    if (ncol(data) == 3 &&
        colnames(data)[1] == "SAMPLE" &&
        colnames(data)[2] == "GENE" &&
        colnames(data)[3] == "CCF") {

      if (input$data_type != "Bulk single") {
        showNotification("Select the correct file type (Bulk single).", type = "error")
        return()
      }

      case("bulk_single")

      data <- distinct(data, SAMPLE, GENE, .keep_all = TRUE)

      mat <- reshape2::acast(data, SAMPLE ~ GENE, value.var = "CCF", fill = 0)

      reshaped_data(mat)
      reshaped_data_matrix(mat)   # BUG FIX: ora sempre popolato

      genotype_table(mat)

      # UI delete controls
      output$DeleteColumn <- render_delete_column_ui("DeleteColumn", "Remove DNA alterations", mat)
      output$DeleteRow    <- render_delete_row_ui("DeleteRow", "Remove samples", mat)

      output$dataTable <- renderDT({
        datatable(mat, options = list(scrollX = TRUE), selection = "single")
      })

      output$heatmapPlot <- renderUI({
        generate_heatmap_plot(mat)
      })

      return()
    }


    # -------------------------------------
    # CASE 2 — BULK MULTIPLE
    # -------------------------------------
    if (ncol(data) == 4 &&
        colnames(data)[1] == "SAMPLE" &&
        colnames(data)[2] == "REGION" &&
        colnames(data)[3] == "GENE" &&
        colnames(data)[4] == "CCF") {

      if (input$data_type != "Bulk multiple") {
        showNotification("Select the correct file type (Bulk multiple).", type = "error")
        return()
      }

      case("bulk_multiple")

      data <- distinct(data, SAMPLE, REGION, GENE, .keep_all = TRUE)

      wide <- data %>%
        group_by(SAMPLE, REGION, GENE) %>%
        summarise(CCF = sum(CCF), .groups = "drop") %>%
        unite("ID", SAMPLE, REGION, sep = "\t") %>%
        tidyr::pivot_wider(names_from = GENE, values_from = CCF, values_fill = 0)

      rownames(wide) <- wide$ID
      wide$ID <- NULL

      reshaped_data(wide)
      reshaped_data_matrix(as.matrix(wide))
      genotype_table(as.matrix(wide))

      # delete UI
      output$DeleteColumn <- render_delete_column_ui("DeleteColumn", "Remove DNA alterations", wide)
      output$DeleteRow    <- render_delete_row_ui("DeleteRow", "Remove samples", wide)

      output$dataTable <- renderDT({
        datatable(wide, options = list(scrollX = TRUE), selection = "single")
      })

      output$heatmapPlot <- renderUI({
        generate_heatmap_plot(wide)
      })

      # Folder selection for models
      shinyDirChoose(input, "dir", roots = c(wd = getwd()), filetypes = c("", "txt"))

      observe({
        req(input$dir)
        selected_folder(parseDirPath(c(wd = getwd()), input$dir))
      })

      return()
    }


    # -------------------------------------
    # CASE 3 — SINGLE CELL
    # -------------------------------------
    if (ncol(data) == 4 &&
        colnames(data)[1] == "PATIENT" &&
        colnames(data)[2] == "CELL" &&
        colnames(data)[3] == "GENE" &&
        colnames(data)[4] == "VALUE") {

      if (input$data_type != "Single cell") {
        showNotification("Select the correct file type (Single cell).", type = "error")
        return()
      }

      case("single_cell")

      data <- distinct(data, PATIENT, CELL, GENE, .keep_all = TRUE)

      avg <- data %>%
        group_by(PATIENT, GENE) %>%
        summarise(PERCENTAGE = mean(VALUE), .groups = "drop") %>%
        tidyr::pivot_wider(names_from = GENE, values_from = PERCENTAGE, values_fill = 0)

      rownames(avg) <- avg$PATIENT
      avg$PATIENT <- NULL

      reshaped_data(avg)
      reshaped_data_matrix(as.matrix(avg))
      genotype_table(as.matrix(avg))

      # delete UI
      output$DeleteColumn <- render_delete_column_ui("DeleteColumn", "Remove DNA alterations", avg)
      output$DeleteRow    <- render_delete_row_ui("DeleteRow", "Remove samples", avg)

      output$dataTable <- renderDT({
        datatable(avg, options = list(scrollX = TRUE), selection = "single")
      })

      output$heatmapPlot <- renderUI({
        generate_heatmap_plot(avg)
      })

      # folder selection (same as bulk multiple)
      shinyDirChoose(input, "dir", roots = c(wd = getwd()), filetypes = c("", "txt"))
      observe({
        req(input$dir)
        selected_folder(parseDirPath(c(wd = getwd()), input$dir))
      })

      return()
    }

    # -------------------------------------
    # FALLBACK — UNRECOGNISED FILE
    # -------------------------------------
    showNotification("File not recognized. Check number of columns and names.", type = "error")
  })


  # ----------------------------------------------------------------------
  # UPDATE reshaped_data & reshaped_data_matrix WHEN DELETE CONTROLS CHANGE
  # ----------------------------------------------------------------------
  observe({
    req(reshaped_data())
    df <- reshaped_data()

    df2 <- apply_modifications(df, input$DeleteColumn, input$DeleteRow)

    reshaped_data(df2)
    reshaped_data_matrix(as.matrix(df2))    # BUG FIX: always updated

    output$dataTable <- renderDT({
      datatable(df2, options = list(scrollX = TRUE), selection = "single")
    })

    output$heatmapPlot <- renderUI({
      generate_heatmap_plot(df2)
    })
  })

}

