module_confidence_server <- function(input, output, session,
                                     reshaped_data2,
                                     resampling_res,
                                     conf_res,
                                     case,
                                     visualizeConfidenceOutput) {


  # ============================================================
  # MAIN BUTTON: CONFIDENCE ESTIMATION
  # ============================================================
  observeEvent(input$submitBtn_conf, {

    # --------------------------
    # PRECHECKS
    # --------------------------
    if (is.null(resampling_res())) {
      showNotification("Run inference before confidence estimation.", type = "error")
      return()
    }

    if (is.null(reshaped_data2()) && case() == "bulk_single") {
      showNotification("Load resampling file before confidence estimation.", type = "error")
      return()
    }

    if (is.null(input$iteration_confEstimation) ||
        is.na(input$iteration_confEstimation) ||
        input$iteration_confEstimation <= 0) {

      showNotification("Specify a valid number of confidence iterations.", type = "error")
      return()
    }

    if (!input$resamplingFlag_conf &&
        (is.null(input$regularization_surv) || is.na(input$regularization_surv))) {

      showNotification("Specify the regularization parameter.", type = "error")
      return()
    }

    if (input$resamplingFlag_conf &&
        (is.null(input$nresampling_conf) || is.na(input$nresampling_conf))) {

      showNotification("Specify the number of resampling cycles.", type = "error")
      return()
    }


    # --------------------------
    # OPEN WAITING MODAL
    # --------------------------
    showModal(modalDialog(
      title = "Processing confidence estimation",
      div(style = "text-align:center;",
          tags$i(class = "fa fa-hourglass-half fa-spin", style = "font-size:40px;"),
          p("Calculating confidence matrix…")
      ),
      easyClose = FALSE,
      footer = NULL
    ))


    # --------------------------
    # RUN CONFIDENCE ESTIMATION
    # --------------------------
    out <- NULL

    tryCatch({

      base_inference <- resampling_res()

      # BULK SINGLE (asceticCCFConfidence)
      if (case() == "bulk_single") {

        if (!input$resamplingFlag_conf) {

          out <- asceticCCFConfidence(
            inference      = base_inference,
            vafDataset     = reshaped_data2(),
            regularization = input$regularization_surv,
            nIterations    = input$iteration_confEstimation
          )

        } else {

          out <- asceticCCFConfidence(
            inference      = base_inference,
            vafDataset     = reshaped_data2(),
            nsampling      = input$nresampling_conf,
            regularization = input$regularization_surv,
            nIterations    = input$iteration_confEstimation
          )
        }
      }


      # BULK MULTIPLE / SINGLE CELL (asceticPhylogeniesConfidence)
      if (case() %in% c("bulk_multiple", "single_cell")) {

        if (!input$resamplingFlag_conf) {

          out <- asceticPhylogeniesConfidence(
            inference      = base_inference,
            regularization = input$regularization_surv,
            nIterations    = input$iteration_confEstimation
          )

        } else {

          out <- asceticPhylogeniesConfidence(
            inference      = base_inference,
            nsampling      = input$nresampling_conf,
            regularization = input$regularization_surv,
            nIterations    = input$iteration_confEstimation
          )
        }
      }


      # SAVE RESULT IN REACTIVE
      conf_res(out)

      # Show UI
      visualizeConfidenceOutput(TRUE)

      removeModal()

      # populate selector
      names_to_remove <- c("dataset", "models", "ccfDataset", "inference")
      names <- setdiff(names(out), names_to_remove)

      output$visualize_conf <- renderUI({
        selectInput("visualize_conf",
                    "Select confidence output",
                    choices = names,
                    selected = names[1])
      })


    }, error = function(e) {

      removeModal()
      showNotification("Confidence estimation failed.", type = "error")
      message("ERROR CONF:", e$message)
      visualizeConfidenceOutput(FALSE)
    })

  })


  # ============================================================
  # DISPLAY CONFIDENCE OUTPUT
  # ============================================================
  observe({

    req(input$sidebarMenu == "confidence")
    req(conf_res())
    req(visualizeConfidenceOutput())
    req(input$visualize_conf)

    out <- conf_res()
    sel <- input$visualize_conf


    # 1. confidence matrix
    if (sel == "confidenceMatrix") {

      df <- out$confidenceMatrix
      df <- round(df, 2)

      output$conf_output <- renderDT({
        datatable(df,
                  options = list(scrollX = TRUE),
                  selection = "single")
      })

      output$graph_conf <- NULL
      return()
    }


    # 2. confidence DAG
    dag <- out[[sel]]

    if (is.null(dag) || all(dag == 0)) {
      showNotification("No confidence DAG available.", type = "message")
      output$graph_conf <- NULL
      output$conf_output <- NULL
      return()
    }

    colnames(dag) <- out$inference$dataset %>% colnames()
    rownames(dag) <- colnames(dag)

    g <- igraph::graph_from_adjacency_matrix(dag)

    g <- igraph::delete_vertices(g, V(g)[degree(g) == 0])

    nodes <- data.frame(id = V(g)$name, label = V(g)$name)
    edges <- as.data.frame(igraph::as_edgelist(g))
    colnames(edges) <- c("from", "to")

    output$conf_output <- NULL

    output$graph_conf <- renderVisNetwork({
      generateVisNetwork(nodes, edges, mode = "confidence")
    })
  })

}
