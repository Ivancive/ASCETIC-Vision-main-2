module_resampling_server <- function(input, output, session,
                                     reshaped_data2) {

  # ------------------------------------------------------------
  # Caricamento resampling file (solo Bulk single)
  # ------------------------------------------------------------
  observeEvent(input$loadBtn2, {

    inFile <- input$dataFile2

    if (is.null(inFile)) {
      showNotification("Please select a file", type = "error")
      return()
    }

    data2 <- tryCatch(
      read.table(inFile$datapath, sep = "\t", header = TRUE, stringsAsFactors = FALSE),
      error = function(e) NULL
    )

    if (is.null(data2)) {
      showNotification("Error reading file", type = "error")
      return()
    }

    expected <- c(
      "SAMPLE", "GENE", "REF_COUNT", "ALT_COUNT",
      "COPY_NUMBER", "NORMAL_PLOIDY", "VAF_ESTIMATE", "CCF_ESTIMATE"
    )

    # check structure
    if (!all(expected %in% colnames(data2))) {
      showNotification("Select the correct resampling file", type = "error")
      return()
    }

    # save table
    reshaped_data2(data2)

    # display table
    output$dataTable2 <- renderDT({
      datatable(data2, options = list(scrollX = TRUE), selection = "single")
    })

    showNotification("Resampling file loaded", type = "message")
  })
}

