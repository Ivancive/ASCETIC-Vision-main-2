module_save_project_server <- function(input, output, session,
                                       case,
                                       case_surv,
                                       reshaped_data,
                                       reshaped_data2,
                                       reshaped_dataSurv,
                                       surv_data,
                                       evo_step,
                                       resampling_res,
                                       conf_res,
                                       resExampleEvosigs) {


  # ============================
  # ABILITAZIONE / DISABILITAZIONE SAVE BUTTON
  # ============================
  observe({
    if (nzchar(input$project_name)) {
      shinyjs::enable("saveBtn")
    } else {
      shinyjs::disable("saveBtn")
    }
  })


  # ============================
  # FUNZIONE DI SALVATAGGIO CSV
  # ============================
  save_csv <- function(obj, path) {
    tryCatch({
      write.table(obj, file = path, sep = ",", quote = FALSE, col.names = NA)
    }, error = function(e) {
      showNotification(paste("Error saving:", basename(path)), type = "error")
    })
  }


  # ============================
  # COSTRUISCI PARAMETRI
  # ============================
  build_parameters <- function() {

    param_names <- c(
      "binarization", "del_col", "del_row", "flag_resampling",
      "nresampling", "restarts", "regularization", "command",
      "seed", "iteration", "flag_confidence", "nresampling_confidence",
      "reg_surv", "flag_surv", "binarization_surv", "data_type",
      "data_type_surv", "binarization_surv2"
    )

    if (!is.null(case_surv()) && case_surv() == "bulk_multiple") {
      param_names <- c(param_names, "binarizationPerc_surv")
    }

    if (!is.null(reshaped_dataSurv())) {
      param_names <- c(param_names, "del_col_surv", "del_row_surv")
    }

    if (!is.null(evo_step())) {
      param_names <- c(param_names, "del_col_surv2", "del_row_surv2")
    }

    values <- sapply(param_names, function(v) {
      val <- input[[v]]
      if (is.null(val)) NA else toString(val)
    }, USE.NAMES = FALSE)

    data.frame(
      name = param_names,
      value = values,
      stringsAsFactors = FALSE
    )
  }


  # ============================
  # MODULO DI SALVATAGGIO
  # ============================
  observeEvent(input$saveBtn, {

    # -------- VALIDAZIONE --------
    if (!nzchar(input$project_name)) {
      showNotification("Enter a valid project name.", type = "error")
      return()
    }

    if (is.null(case())) {
      showNotification("Load genomic data before saving.", type = "error")
      return()
    }

    # -------- COSTRUZIONE CARTELLA --------
    project_name <- paste0(input$project_name, "_", case())
    dir_main <- file.path("output_project", project_name)

    if (!dir.exists(dir_main)) {
      dir.create(dir_main, recursive = TRUE)
    }


    # -------- SALVATAGGI PRINCIPALI --------
    save_csv(reshaped_data(), file.path(dir_main, "genotipo.csv"))

    if (!is.null(reshaped_dataSurv())) {
      save_csv(reshaped_dataSurv(), file.path(dir_main, "genotipo_surv.csv"))
    }

    if (!is.null(surv_data())) {
      save_csv(surv_data(), file.path(dir_main, "surv_data.csv"))
    }

    if (!is.null(evo_step())) {
      save_csv(evo_step(), file.path(dir_main, "evo_step.csv"))
    }

    if (!is.null(reshaped_data2())) {
      save_csv(reshaped_data2(), file.path(dir_main, "resampling_table.csv"))
    }

    # -------- SALVATAGGI RDS --------
    if (!is.null(resampling_res())) {
      saveRDS(resampling_res(), file.path(dir_main, "resampling_res.rds"))
    }

    if (!is.null(conf_res())) {
      saveRDS(conf_res(), file.path(dir_main, "confidence_res.rds"))
    }

    if (!is.null(resExampleEvosigs())) {
      saveRDS(resExampleEvosigs(), file.path(dir_main, "resExampleEvosigs.rds"))
    }

    # -------- PARAMETRI --------
    write.table(
      build_parameters(),
      file = file.path(dir_main, "parameters.csv"),
      sep = ",", quote = FALSE, row.names = FALSE
    )


    # -------- CASI SPECIFICI: BULK MULTIPLE --------
    if (case() == "bulk_multiple") {

      df <- data.frame(
        name = c("directory", "binarization_perc"),
        value = c(
          toString(input$dir),
          toString(input$binarization_perc)
        ),
        stringsAsFactors = FALSE
      )

      write.table(
        df,
        file = file.path(dir_main, "parameters_bulk_multiple.csv"),
        sep = ",", quote = FALSE, row.names = FALSE
      )
    }


    # -------- CASI SPECIFICI: SINGLE CELL --------
    if (case() == "single_cell") {

      df <- data.frame(
        name = "directory",
        value = toString(input$dir),
        stringsAsFactors = FALSE
      )

      write.table(
        df,
        file = file.path(dir_main, "parameters_single_cell.csv"),
        sep = ",", quote = FALSE, row.names = FALSE
      )
    }

    # -------- TIMESTAMP --------
    writeLines(as.character(Sys.time()),
               con = file.path(dir_main, "modified_time.csv"))

    # -------- FINE --------
    showNotification("Project saved successfully.", type = "message")
  })

}

