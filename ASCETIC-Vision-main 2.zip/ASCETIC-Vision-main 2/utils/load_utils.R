# ===========================================================
# utils/load_utils.R
# Loader sicuro delle utilities (nessuna ricorsione)
# ===========================================================

# ATTENZIONE:
# - Questo file NON deve mai richiamare se stesso con source().
# - Nessun shinyApp(), nessun ui/server qui.
# - Solo caricamento di funzioni di utilità.

# Opzione 1: (per partire sicuri) — NON caricare automaticamente nulla,
# lasciandolo come stub. Puoi aggiungere funzioni qui dentro direttamente.
invisible(TRUE)

# -----------------------------------------------------------
# Se poi vorrai caricare automaticamente altri file in utils/,
# usa SOLO questo blocco, SENZA richiamare load_utils.R di nuovo:
# -----------------------------------------------------------
# utility_files <- list.files("utils", pattern = "\\.R$", full.names = TRUE)
# utility_files <- utility_files[basename(utility_files) != "load_utils.R"]
#
# for (f in utility_files) {
#   source(f, local = TRUE)
# }
# -----------------------------------------------------------

