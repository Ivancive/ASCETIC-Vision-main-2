generateVisNetwork <- function(nodes, edges, title = "", subtitle = "", poset = NULL) {
  visNetwork::visNetwork(nodes, edges, height = "600px") %>%
    visNetwork::visNodes(shape = "box") %>%
    visNetwork::visEdges(arrows = "to") %>%
    visNetwork::visOptions(highlightNearest = TRUE) %>%
    visNetwork::visLayout(randomSeed = 1)
}

