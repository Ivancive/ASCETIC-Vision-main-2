generate_heatmap_plot <- function(mat) {
  req(mat)

  p <- ggplot(
    reshape2::melt(as.matrix(mat)),
    aes(Var2, Var1, fill = value)
  ) +
    geom_tile() +
    scale_fill_gradient(low = "white", high = "red") +
    theme_minimal() +
    theme(axis.text.x = element_text(angle = 45, hjust = 1))

  plotly::ggplotly(p)
}

