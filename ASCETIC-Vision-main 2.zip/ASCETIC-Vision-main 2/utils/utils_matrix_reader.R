readMatrixFiles <- function(folder) {
  files <- list.files(folder, full.names = TRUE)
  out <- list()

  for (f in files) {
    mat <- tryCatch({
      as.matrix(read.table(f, sep = "\t", header = TRUE, row.names = 1))
    }, error = function(e) NULL)

    if (!is.null(mat)) {
      out[[basename(f)]] <- mat
    }
  }
  out
}

