save_csv <- function(obj, path) {
  tryCatch({
    write.table(obj, file = path, sep = ",", quote = FALSE, col.names = NA)
  }, error = function(e) {
    warning(paste("Error saving:", basename(path)))
  })
}

save_rds_safe <- function(obj, path) {
  tryCatch({
    saveRDS(obj, path)
  }, error = function(e) {
    warning(paste("Error saving RDS:", basename(path)))
  })
}

read_genotype_file <- function(path) {
  read.table(path, sep = "\t", header = TRUE, stringsAsFactors = FALSE)
}

