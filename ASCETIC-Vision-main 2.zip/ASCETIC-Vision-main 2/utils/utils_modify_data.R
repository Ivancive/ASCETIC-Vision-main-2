modify_reshaped_data <- function(data, del_col = NULL, del_row = NULL) {
  out <- data

  if (!is.null(del_col) && nchar(del_col) > 0) {
    cols <- trimws(unlist(strsplit(del_col, ",")))
    cols <- cols[cols %in% colnames(out)]
    out <- out[, setdiff(colnames(out), cols), drop = FALSE]
  }

  if (!is.null(del_row) && nchar(del_row) > 0) {
    rows <- trimws(unlist(strsplit(del_row, ",")))
    rows <- rows[rows %in% rownames(out)]
    out <- out[setdiff(rownames(out), rows), , drop = FALSE]
  }

  return(out)
}

modify_reshaped_dataSurv <- modify_reshaped_data

