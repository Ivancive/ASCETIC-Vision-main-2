binarize_matrix <- function(mat, threshold) {
  if (is.null(threshold) || is.na(threshold)) return(mat)
  ifelse(mat >= threshold, 1, 0)
}

filter_prevalence <- function(mat, threshold) {
  prev <- colMeans(mat == 1)
  mat[, prev >= threshold, drop = FALSE]
}

