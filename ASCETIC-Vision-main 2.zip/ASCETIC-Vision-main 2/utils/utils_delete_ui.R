render_delete_column_ui <- function(id, label, data) {
  req(data)
  tagList(
    textInput(id, label, placeholder = "Comma-separated column names"),
    bsTooltip(id, "Specify columns to remove", placement = "right")
  )
}

render_delete_row_ui <- function(id, label, data) {
  req(data)
  tagList(
    textInput(id, label, placeholder = "Comma-separated row names"),
    bsTooltip(id, "Specify rows to remove", placement = "right")
  )
}

